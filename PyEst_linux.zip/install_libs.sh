sudo apt-get install python3.5
python3.5 -m pip install numpy matplotlib scipy pandas
